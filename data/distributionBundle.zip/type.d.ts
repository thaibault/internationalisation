import { DomNodes as BaseDomNodes, HTMLItem, Mapping, Options as BaseOptions, UnknownFunction, $DomNodes as $BaseDomNodes, $T } from 'clientnode/type';
export declare type InternationalisationFunction<TElement = HTMLElement> = (..._parameters: Array<unknown>) => Promise<$T<TElement>>;
declare global {
    interface JQuery<TElement = HTMLElement> {
        Internationalisation: InternationalisationFunction<TElement>;
    }
}
export interface Replacement {
    $textNodeToTranslate: $T<HTMLItem>;
    $nodeToReplace: $T<HTMLItem>;
    textToReplace: string;
    $currentLanguageDomNode: null | $T<HTMLItem>;
}
export declare type DomNodes<Type = string> = BaseDomNodes & {
    knownTranslation: Type;
};
export declare type $DomNodes = $BaseDomNodes & {
    switchLanguageButtons: $T<HTMLLinkElement>;
};
export interface DefaultOptions {
    currentLanguageIndicatorClassName: string;
    currentLanguagePattern: string;
    default: string;
    domNodes: DomNodes;
    fadeEffect: boolean;
    initial: null | string;
    languageHashPrefix: string;
    languageMapping: Mapping<Array<string>>;
    lockDescription: string;
    name: string;
    onSwitched: UnknownFunction;
    onEnsured: UnknownFunction;
    onSwitch: UnknownFunction;
    onEnsure: UnknownFunction;
    preReplacementLanguagePattern: string;
    replaceDomNodeNames: Array<string>;
    replacementDomNodeName: Array<string>;
    replacementLanguagePattern: string;
    selection: Array<string>;
    sessionDescription: string;
    templateDelimiter: {
        pre: string;
        post: string;
    };
    textNodeParent: {
        hideAnimation: [Mapping<number | string>, Mapping<number | string>];
        showAnimation: [Mapping<number | string>, Mapping<number | string>];
    };
}
export declare type Options = BaseOptions & DefaultOptions;
