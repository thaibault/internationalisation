import { HTMLItem, Mapping } from 'clientnode';
export interface Replacement {
    textNodeToTranslate: HTMLItem;
    nodeToReplaceWith: HTMLItem;
    textToReplaceWith: string;
    currentLanguageDomNode: HTMLItem | null;
}
export interface DefaultOptions {
    currentLanguageIndicatorClassName: string;
    currentLanguagePattern: string;
    default: string;
    useEffect: boolean;
    initial: null | string;
    languageHashPrefix: string;
    languageMapping: Mapping<Array<string>>;
    lockDescription: string;
    preReplacementLanguagePattern: string;
    replaceDomNodeNames: Array<string>;
    replacementDomNodeNames: Array<string>;
    replacementLanguagePattern: string;
    selection: Array<string>;
    selectors: {
        knownTranslation: string;
    };
    sessionDescription: string;
    templateDelimiter: (null | {
        pre: string;
        post: string;
    });
}
export type Options = DefaultOptions;
