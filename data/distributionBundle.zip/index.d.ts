import { $T, BoundTools, HTMLItem, Lock, Mapping, RecursivePartial } from 'clientnode';
import { DefaultOptions, Options, Replacement, $DomNodes } from './type';
/**
 * This plugin holds all needed methods to extend a website for
 * internationalisation.
 * @property _defaultOptions - Options extended by the options given to the
 * initializer method.
 * @property _defaultOptions.currentLanguageIndicatorClassName - Class name
 * which marks current language switcher button or link.
 * @property _defaultOptions.currentLanguagePattern - Saves a pattern to
 * recognize current language marker.
 * @property _defaultOptions.domNodes - A mapping of needed internal dom node
 * descriptions to their corresponding selectors.
 * @property _defaultOptions.domNodeSelectorPrefix - Selector prefix for all
 * nodes to take into account.
 * @property _defaultOptions.default - Initial language to use.
 * @property _defaultOptions.selection - List of all supported languages.
 * @property _defaultOptions.initial - Initial set language (if omitted it will
 * be determined based on environment informations).
 * @property _defaultOptions.templateDelimiter - Template delimiter to
 * recognize dynamic content.
 * @property _defaultOptions.templateDelimiter.pre - Delimiter which introduces
 * a dynamic expression.
 * @property _defaultOptions.templateDelimiter.post - Delimiter which finishes
 * a dynamic expression.
 * @property _defaultOptions.fadeEffect - Indicates whether a fade effect
 * should be performed.
 * @property _defaultOptions.textNodeParent - Saves informations how parent dom
 * nodes should be animated when containing text will be switched.
 * @property _defaultOptions.textNodeParent.showAnimation - Fade in options
 * when a new text should appear.
 * @property _defaultOptions.textNodeParent.hideAnimation - Fade out effect
 * options when a text node should be removed before switching them.
 * @property _defaultOptions.preReplacementLanguagePattern - Pattern to
 * introduce a pre replacement language node.
 * @property _defaultOptions.replacementLanguagePattern - Text pattern to
 * introduce a post replacement node.
 * @property _defaultOptions.replacementDomNodeName - Dom node tag name which
 * should be interpreted as a hidden alternate language node (contains text in
 * another language).
 * @property _defaultOptions.replaceDomNodeNames - Tag names which indicates
 * dom nodes which should be replaced.
 * @property _defaultOptions.lockDescription - Lock description.
 * @property _defaultOptions.languageHashPrefix - Hash prefix to determine
 * current active language by url.
 * @property _defaultOptions.sessionDescription - Name to use for saving
 * preferred language in local storage for current session.
 * @property _defaultOptions.languageMapping - A mapping of alternate language
 * descriptions.
 * @property _defaultOptions.onSwitched - Callback which will be triggered
 * after a language switch has been finished.
 * @property _defaultOptions.onEnsured - Callback which will be triggered after
 * a language check has been performed. Needed if some nodes have another
 * language active then others. Useful if only some parts of the dom tree was
 * updated and a full language update isn't required.
 * @property _defaultOptions.onSwitch - Callback which should be called before
 * a language switch should be performed.
 * @property _defaultOptions.onEnsure - Callback which should be called before
 * a language switch should be ensured.
 * @property options - Finally configured given options.
 * @property currentLanguage - Saves the current language.
 * @property knownTranslations - Saves a mapping of known language strings and
 * their corresponding translations, to boost language replacements or saves
 * redundant replacements in dom tree.
 * @property lock - Lock instance when updating dom noes.
 * @property _$domNodeToFade - Saves all $-extended dom nodes which should be
 * animated.
 * @property _replacements - Saves all text nodes which should be replaced.
 * @property _textNodesWithKnownTranslation - Saves a mapping of known text
 * snippets to their corresponding $-extended dom nodes.
 */
export declare class Internationalisation<TElement = HTMLElement> extends BoundTools<TElement> {
    static _defaultOptions: DefaultOptions;
    $domNodes: $DomNodes;
    currentLanguage: string;
    knownTranslations: Mapping;
    lock: Lock<string | undefined>;
    options: Options;
    _$domNodeToFade: null | $T;
    _replacements: Array<Replacement>;
    _textNodesWithKnownTranslation: Mapping<$T<HTMLItem>>;
    /**
     * Initializes the plugin. Current language is set and later needed dom
     * nodes are grabbed.
     * @param options - An options object.
     * @returns Returns the current instance wrapped in a promise.
     */
    initialize<R = Promise<$T<TElement>>>(options?: RecursivePartial<Options>): R;
    /**
     * Switches the current language to given language. This method is mutual
     * synchronized.
     * @param language - New language as string or "true". If set to "true" it
     * indicates that the dom tree should be checked again current language to
     * ensure every text node has right content.
     * @param ensure - Indicates if a switch effect should be avoided.
     * @returns Returns the current instance wrapped in a promise.
     */
    switch(language: string | true, ensure?: boolean): Promise<$T<TElement>>;
    /**
     * Ensures current selected language.
     * @returns Returns the current instance wrapped in a promise.
     */
    refresh(): Promise<$T<TElement>>;
    /**
     * Depending on activated switching effect this method initialized the
     * effect of replace all text string directly.
     * @param language - New language to use.
     * @param ensure - Indicates if current language should be ensured again
     * every text node content.
     * @returns Returns the current instance wrapped in a promise.
     */
    _handleSwitchEffect(language: string, ensure: boolean): Promise<void>;
    /**
     * Moves pre replacement dom nodes into next dom node behind translation
     * text to use the same translation algorithm for both.
     */
    _movePreReplacementNodes(): void;
    /**
     * Collects all text nodes which should be replaced later.
     * @param language - New language to use.
     * @param ensure - Indicates if the whole dom should be checked again
     * current language to ensure every text node has right content.
     * @returns Return a tuple of last text and language dom node to translate.
     */
    _collectTextNodesToReplace(language: string, ensure: boolean): Array<null | $T<HTMLItem>>;
    /**
     * Iterates all text nodes in language known area with known translations.
     */
    _registerKnownTextNodes(): void;
    /**
     * Normalizes a given language string.
     * @param language - New language to use.
     * @returns Returns the normalized version of given language.
     */
    _normalizeLanguage(language: string): string;
    /**
     * Determines a useful initial language depending on session and browser
     * settings.
     * @returns Returns the determined language.
     */
    _determineUsefulLanguage(): string;
    /**
     * Registers a text node to change its content with given replacement.
     * @param $textNode - Text node with content to translate.
     */
    _addTextNodeToFade($textNode: $T<HTMLItem>): void;
    /**
     * Registers a text node to change its content with given replacement.
     * @param $currentTextNodeToTranslate - Text node with content to
     * translate.
     * @param $currentDomNode - A comment node with replacement content.
     * @param match - A matching array of replacement's text content.
     * @param $currentLanguageDomNode - A potential given text node indicating
     * the language of given text node.
     */
    _registerTextNodeToChange($currentTextNodeToTranslate: $T<HTMLItem>, $currentDomNode: $T<HTMLItem> | null, match: Array<string>, $currentLanguageDomNode: null | $T): void;
    /**
     * Checks if last text node has a language indication comment node. This
     * function is called after each parsed dom text node.
     * @param $lastTextNodeToTranslate - Last text node to check.
     * @param $lastLanguageDomNode - A potential given language indication
     * commend node.
     * @param ensure - Indicates if current language should be ensured again
     * every text node content.
     * @returns Returns the retrieved or newly created language indicating
     * comment node.
     */
    _ensureLastTextNodeHavingLanguageIndicator($lastTextNodeToTranslate: null | $T<HTMLItem>, $lastLanguageDomNode: null | $T<HTMLItem>, ensure: boolean): null | $T<HTMLItem>;
    /**
     * Performs the low level text replacements for switching to given
     * language.
     * @param language - The new language to switch to.
     */
    _switchLanguage(language: string): void;
    /**
     * Switches the current language indicator in language switch triggered dom
     * nodes.
     * @param language - The new language to switch to.
     */
    _switchCurrentLanguageIndicator(language: string): void;
}
export default Internationalisation;
