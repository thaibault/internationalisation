import { HTMLItem, Lock, Logger, Mapping } from 'clientnode';
import { WebComponentAPI } from 'web-component-wrapper/type';
import { Web } from 'web-component-wrapper/Web';
import { DefaultOptions, Options, Replacement } from './type';
export declare const log: Logger;
/**
 * This plugin holds all needed methods to extend a website for
 * internationalization.
 * @property _defaultOptions - Options extended by the options given to the
 * initializer method.
 * @property _defaultOptions.currentLanguageIndicatorClassName - Class name
 * which marks current language switcher button or link.
 * @property _defaultOptions.currentLanguagePattern - Saves a pattern to
 * recognize current language marker.
 * @property _defaultOptions.default - Initial language to use.
 * @property _defaultOptions.useEffect - Indicates whether a fade effect
 * should be performed.
 * @property _defaultOptions.initial - Initial set language (if omitted it will
 * be determined based on environment information).
 * @property _defaultOptions.languageHashPrefix - Hash prefix to determine
 * current active language by url.
 * @property _defaultOptions.languageMapping - A mapping of alternate language
 * descriptions.
 * @property _defaultOptions.lockDescription - Lock description.
 * @property _defaultOptions.preReplacementLanguagePattern - Pattern to
 * introduce a pre replacement language node.
 * @property _defaultOptions.replaceDomNodeNames - Tag names which indicates
 * dom nodes which should be replaced.
 * @property _defaultOptions.replacementDomNodeNames - Dom node tag name which
 * should be interpreted as a hidden alternate language node (contains text in
 * another language).
 * @property _defaultOptions.replacementLanguagePattern - Text pattern to
 * introduce a post replacement node.
 * @property _defaultOptions.selection - List of all supported languages.
 * @property _defaultOptions.selectors - Mapping of needed dom node selectors.
 * @property _defaultOptions.selectors.knownTranslation - Selector to find
 * known translation sections.
 * @property _defaultOptions.sessionDescription - Description to save current
 * language in session storage.
 * @property _defaultOptions.templateDelimiter - Template delimiter to
 * recognize dynamic content.
 * @property _defaultOptions.templateDelimiter.pre - Delimiter which introduces
 * a dynamic expression.
 * @property _defaultOptions.templateDelimiter.post - Delimiter which finishes
 * a dynamic expression.
 * @property options - Finally configured given options.
 * @property currentLanguage - Saves the current language.
 * @property knownTranslations - Saves a mapping of known language strings and
 * their corresponding translations, to boost language replacements or saves
 * redundant replacements in dom tree.
 * @property lock - Lock instance when updating dom noes.
 * @property _domNodesToFade - Saves all dom nodes which should be animated.
 * @property _replacements - Saves all text nodes which should be replaced.
 * @property _textNodesWithKnownTranslation - Saves a mapping of known text
 * snippets to their corresponding $-extended dom nodes.
 */
export declare class WebInternationalization<TElement = HTMLElement, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>> extends Web<TElement, ExternalProperties, InternalProperties> {
    static _name: string;
    static _defaultOptions: DefaultOptions;
    readonly self: typeof WebInternationalization;
    options: Options;
    onEnsure: (language: string) => Promise<void>;
    onSwitch: (oldLanguage: string, newLanguage: string) => Promise<void>;
    onEnsured: (language: string) => void;
    onSwitched: (oldLanguage: string, newLanguage: string) => void;
    switchLanguageButtonDomNodes: NodeListOf<HTMLAnchorElement> | null;
    currentLanguage: string;
    knownTranslations: Mapping;
    lock: Lock<string | undefined>;
    _domNodesToFade: Array<HTMLElement>;
    _replacements: Array<Replacement>;
    _textNodesWithKnownTranslation: Mapping<Array<HTMLItem>>;
    /**
     * Triggered when ever a given attribute has changed and triggers to update
     * configured dom content.
     * @param name - Attribute name which was updates.
     * @param newValue - New updated value.
     */
    onUpdateAttribute(name: string, newValue: string): void;
    /**
     * Initializes the component. Current language is set and later needed dom
     * nodes are grabbed.
     */
    connectedCallback(): void;
    /**
     * Switches the current language to given language. This method is mutual
     * synchronized.
     * @param language - New language as string or "true". If set to "true" it
     * indicates that the dom tree should be checked again current language to
     * ensure every text node has right content.
     * @param ensure - Indicates if a switch effect should be avoided.
     * @returns Returns the current instance wrapped in a promise.
     */
    switch(language: string | true, ensure?: boolean): Promise<void>;
    /**
     * Ensures current selected language.
     * @returns Promise resolving to nothing when switching as finished.
     */
    refresh(): Promise<void>;
    /**
     * Depending on activated switching effect this method initialized the
     * effect of replace all text string directly.
     * @param language - New language to use.
     * @param ensure - Indicates if current language should be ensured again
     * every text node content.
     * @returns Returns the current instance wrapped in a promise.
     */
    _handleSwitchEffect(language: string, ensure: boolean): Promise<void>;
    /**
     * Moves pre replacement dom nodes into next dom node behind translation
     * text to use the same translation algorithm for both.
     */
    _movePreReplacementNodes(): void;
    /**
     * Collects all text nodes which should be replaced later.
     * @param language - New language to use.
     * @param ensure - Indicates if the whole dom should be checked again
     * current language to ensure every text node has right content.
     */
    _collectTextNodesToReplace(language: string, ensure: boolean): void;
    /**
     * Iterates all text nodes in language known area with known translations.
     */
    _registerKnownTextNodes(): void;
    /**
     * Normalizes a given language string.
     * @param language - New language to use.
     * @returns Returns the normalized version of given language.
     */
    _normalizeLanguage(language: string): string;
    /**
     * Determines a useful initial language depending on session and browser
     * settings.
     * @returns Returns the determined language.
     */
    _determineUsefulLanguage(): string;
    /**
     * Registers a text node to change its content with given replacement.
     * @param currentTextNodeToTranslate - Text node with content to
     * translate.
     * @param currentDomNode - A comment node with replacement content.
     * @param match - A matching array of replacement's text content.
     * @param currentLanguageDomNode - A potential given text node indicating
     * the language of given text node.
     */
    _registerTextNodeToChange(currentTextNodeToTranslate: HTMLItem, currentDomNode: HTMLItem | null, match: Array<string>, currentLanguageDomNode: HTMLItem | null): void;
    /**
     * Checks if last text node has a language indication comment node. This
     * function is called after each parsed dom text node.
     * @param lastTextNodeToTranslate - Last text node to check.
     * @param lastLanguageDomNode - A potential given language indication
     * commend node.
     * @param ensure - Indicates if current language should be ensured again
     * every text node content.
     * @returns Returns the retrieved or newly created language indicating
     * comment node.
     */
    _ensureLastTextNodeHavingLanguageIndicator(lastTextNodeToTranslate: HTMLItem | null, lastLanguageDomNode: HTMLItem | null, ensure: boolean): HTMLItem | null;
    /**
     * Performs the low level text replacements for switching to given
     * language.
     * @param language - The new language to switch to.
     */
    _switchLanguage(language: string): void;
    /**
     * Switches the current language indicator in language switch triggered dom
     * nodes.
     * @param language - The new language to switch to.
     */
    _switchCurrentLanguageIndicator(language: string): void;
}
export declare const api: WebComponentAPI<HTMLElement, Mapping<unknown>, Mapping<unknown>, typeof Web>;
export default WebInternationalization;
